//
//  HikingTrail.swift
//  HikingTrails_Spring23
//
//  Created by Don Almeida on 2/20/23.
//

import Foundation
import UIKit

class HikingTrail {
    var TrailName = ""
    var TrailDescription = ""
    var TrailLength = ""
    var TrailElevation = ""
    var TrailTime = ""
    var TrailRouteType = ""
    var TrailDifficulty = ""
    var TrailImageName = ""
    var TrailWebSiteAddress = ""
    
}

